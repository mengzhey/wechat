
const keys =
  [
    'responseOrSuggestion',
    'promptResponse',
    'promptSuggestion',
    'chatExample',
    'systemPrompt'
  ];

const values = {};
let prompt = "";
let systemPrompt = "";

const promises = keys.map(key => {
  return new Promise((resolve, reject) => {
    chrome.storage.sync.get(key, function(data) {
      values[key] = data[key] || '';
      // console.log(values[key]);
      resolve();
    });
  });
});

Promise.all(promises).then(() => {

  // system prompt
  systemPrompt += values['systemPrompt'];
  let chatExample = values['chatExample'];

  systemPrompt.replace('<chatExample>', chatExample);

  // extra prompt for response or suggestions
  let extraPrompt = "";
  if (values['responseOrSuggestion'] === 'response') {
    extraPrompt = values['promptResponse'];
  }
  else {
    extraPrompt = values['promptSuggestion'];
  }

  systemPrompt = systemPrompt + extraPrompt;

  console.log(systemPrompt);
});


let getConversation = (numDialogue) => {
  let dialogue = document.querySelectorAll('._aadf');
  let texts = [];
  let isLeft = [];
  for (let i = 0; i < dialogue.length; i++) {
    try {
      let dial = dialogue[i];

      let right = dial.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.className.includes('_acd2');
      let text = dial.children[0].innerHTML;

      isLeft.push(!right);
      texts.push(text);

    } catch (e) {
    }
  }
  let conversation = [];

  texts = texts.slice(-numDialogue);
  for (let i = 0; i < texts.length; i++) {
    if (isLeft[i]) {
      conversation.push("They: ");
      conversation.push(texts[i]);
      conversation.push("\n");
    } else {
      conversation.push("Me: ");
      conversation.push(texts[i]);
      conversation.push("\n");

    }
  }
  conversation = conversation.join(" ");

  return conversation;
}

let getCurrentText = () => {
  let currentText = document.querySelectorAll('textarea')[0].innerHTML;
  if (currentText.length === 0) {
    return false;
  }
  else {
    return currentText;
  }
}

let createPrompt = (conversation, currentText) => {
    let prompt = "Previous conversation: <conversation>\n My message to send: <currentText>";

    prompt = prompt.replace("<conversation>", conversation);
    prompt = prompt.replace("<currentText>", currentText);

    return prompt;
}


let extractResponse = (response)=>{
  if (response.includes('yes') || response.includes('Yes')) {
    return [true, ''];
  }
  else {
    let suggestion = response.substring(response.indexOf('"') + 1, response.indexOf('"', response.indexOf('"') + 1));
    return [false, suggestion];
  }
}

let replaceText = (text)=>{
  document.querySelectorAll('textarea')[0].value = text;
  const event = new Event('input', { bubbles: true});
  document.querySelectorAll('textarea')[0].dispatchEvent(event);
}

let popUpWindow = (isGood, fullResponse, suggestion)=>{
  let text0 = "";
  let text1 = "";

  if (isGood) {
    text0 = "Yes response looks good to me. Go ahead!";
  }
  else {
    text0 = fullResponse + "\n";

    text1 = suggestion;
    if (values['responseOrSuggestion'] !== 'response') {
      text1 = "";
    }
  }


  // Create the mask div
  let maskDiv = document.createElement('div');
  maskDiv.style.position = 'fixed';
  maskDiv.style.top = '0';
  maskDiv.style.left = '0';
  maskDiv.style.width = '100%';
  maskDiv.style.height = '100%';
  maskDiv.style.backgroundColor = 'rgba(0, 0, 0, 0.5)'; // Set black color with 50% transparency

  let popupDiv = document.createElement('div');
  popupDiv.style.position = 'fixed';
  popupDiv.style.top = '50%';
  popupDiv.style.left = '10%';
  popupDiv.style.transform = 'translate(-5%, -50%)';
  popupDiv.style.backgroundColor = 'white';
  popupDiv.style.padding = '50px';
  popupDiv.style.borderRadius = '6px';
  popupDiv.style.textAlign = 'justify';
  popupDiv.style.fontFamily = 'var(--font-family-system)';
  popupDiv.style.lineHeight = 'var(--system-16-line-height)';
  popupDiv.style.fontSize = 'var(--system-16-font-size)';
  popupDiv.style.fontWeight = 'var(--font-weight-system-regular)';
  // popupDiv.style.border = '1px solid #ccc';

  let text0Div = document.createElement('div');
  // text0Div.style.fontWeight = 'var(--font-weight-system-regular)';
  // text0Div.style.color = '#555';
  text0Div.innerText = text0;
  popupDiv.appendChild(text0Div);
  if (text1.length) {
    let text1Div = document.createElement('div');
    text1Div.style.paddingTop = '30px';
    text1Div.style.fontWeight = 'var(--font-weight-system-semibold)';
    popupDiv.style.fontSize = 'var(--system-15-font-size)';
    // text1Div.style.color = '#000';
    text1Div.innerText = text1;
    popupDiv.appendChild(text1Div);
  }

  let buttonStylePrimary = {};
  buttonStylePrimary.paddingLeft = '0px';
  buttonStylePrimary.paddingRight = '0px';
  buttonStylePrimary.paddingTop = '11px';
  buttonStylePrimary.paddingBottom = '11px';
  buttonStylePrimary.marginTop = '40px';
  buttonStylePrimary.marginLeft = '0px';
  buttonStylePrimary.marginRight = '0px';
  buttonStylePrimary.fontSize = 'var(--system-16-font-size)';
  buttonStylePrimary.fontWeight = 'var(--font-weight-system-regular)';
  buttonStylePrimary.width = '50%';
  buttonStylePrimary.borderRadius = '0px';
  buttonStylePrimary.border = '0px';
  buttonStylePrimary.backgroundColor = '#bbb';
  buttonStylePrimary.border = '1px solid #bbb';


  let buttonStyleSecondary = Object.assign({}, buttonStylePrimary);
  buttonStyleSecondary.backgroundColor = '#ddd';
  buttonStyleSecondary.border = '1px solid #ddd';

  function addButtonHoverEffect(button, hoverStyle, unHoverStyle) {
    button.addEventListener('mouseenter', () => {
      for (let key in hoverStyle) {
        button.style[key] = hoverStyle[key];
      }
      button.style.cursor = 'pointer';
    });

    button.addEventListener('mouseleave', () => {
      for (let key in unHoverStyle) {
        button.style[key] = unHoverStyle[key]; // Reset the style to its original state
      }
      button.style.cursor = 'default';
    });
  }

  let buttonHoverStylePrimary = {
    // Add any desired hover effects, e.g., change background color, border color, etc.
    backgroundColor: '#aaa',
    // borderColor: '#aaa',
  };


  let buttonUnHoverStylePrimary = {
    // Add any desired hover effects, e.g., change background color, border color, etc.
    backgroundColor: '#bbb',
    // borderColor: '#aaa',
  };


  let buttonHoverStyleSecondary = {
    // Add any desired hover effects, e.g., change background color, border color, etc.
    backgroundColor: '#ccc',
    // borderColor: '#ccc',
  };

  let buttonUnHoverStyleSecondary = {
    // Add any desired hover effects, e.g., change background color, border color, etc.
    backgroundColor: '#ddd',
    // borderColor: '#aaa',
  };


  function assignStyle(btn, style) {
    for (let key in style) {
      btn.style[key] = style[key];
    }
  }

  let okButton = document.createElement('button');
  okButton.innerText = 'OK';
  // okButton.style = buttonStylePrimary;
  assignStyle(okButton, buttonStylePrimary);
  okButton.style['width'] = '100%';
  addButtonHoverEffect(okButton, buttonHoverStylePrimary, buttonUnHoverStylePrimary);
  okButton.addEventListener('click', () => {
    popupDiv.remove();
    maskDiv.remove();
  });


  let replaceButton = document.createElement('button');
  replaceButton.innerText = 'Replace';
  // replaceButton.style = buttonStylePrimary;
  assignStyle(replaceButton, buttonStylePrimary);
  addButtonHoverEffect(replaceButton, buttonHoverStylePrimary, buttonUnHoverStylePrimary);
  replaceButton.addEventListener('click', () => {
    popupDiv.remove();
    maskDiv.remove();
    replaceText(suggestion);
  });

  let noButton = document.createElement('button');
  noButton.innerText = 'Cancel';
  assignStyle(noButton, buttonStyleSecondary);
  addButtonHoverEffect(noButton, buttonHoverStyleSecondary, buttonUnHoverStyleSecondary);
  // noButton.style = buttonStyleSecondary;
  noButton.addEventListener('click', () => {
    popupDiv.remove();
    maskDiv.remove();
  });


  console.log(values['responseOrSuggestion'])
  if (isGood || values['responseOrSuggestion'] === 'suggestion') {
    popupDiv.appendChild(okButton);
  }
  else {
    popupDiv.appendChild(replaceButton);
    popupDiv.appendChild(noButton);
  }

  document.body.appendChild(popupDiv);
  popupDiv.style.zIndex = '9999';

  document.body.appendChild(maskDiv);
  maskDiv.style.zIndex = '9998'; // Set zIndex to a value lower than the popup div

}

let askMindMate = () => {

  let conversation = getConversation(5);
  let currentText = getCurrentText();

  let prompt = createPrompt(conversation, currentText);
  console.log('prompt: \n' + prompt);
  console.log('system prompt: \n' + systemPrompt);

  let body = JSON.stringify({
    model: 'gpt-3.5-turbo',
    messages: [
      {"role": "system", "content": systemPrompt},
      {"role": "user", "content": prompt}
    ],
    max_tokens: 150,
    temperature: 0.0
  });


  fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer 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'
    },
    body: body
  })
  .then(response => response.json())
  .then(response => {
    console.log(response)
    let text = response.choices[0].message.content;
    console.log(text);

    let isGood = false;
    let suggestion = "";
    [isGood, suggestion] = extractResponse(text);
    popUpWindow(isGood, text, suggestion)


    window.appDiv.innerHTML = '<img style="height: 100%" src="https://img.freepik.com/premium-vector/bunny-ears-icon-vector-illustration_333603-620.jpg?w=360" alt="Loading...">';

  })
  .catch(error => {
    console.log(error);
  });
}


let addButton= ()=>{

  const buttonElement = document.createElement('button');
  buttonElement.className = '_abl-';
  buttonElement.type = 'button';

  const appDiv = document.createElement('div');
  window.appDiv = appDiv;
  appDiv.className = '_abm0';
  appDiv.style.fontSize = '30px';
  appDiv.style.lineHeight = '50px';
  appDiv.style.fontWeight = '340';
  appDiv.style.height = "100%";
  appDiv.innerHTML = '<img style="height: 100%" src="https://img.freepik.com/premium-vector/bunny-ears-icon-vector-illustration_333603-620.jpg?w=360" alt="Loading...">';

  //
  // let button = document.createElement('button');
  // button.textContent = 'Click me';
  // document.body.appendChild(button);

  function onButtonClick() {
    // Replace the button text with a loading GIF
    appDiv.innerHTML = '<img style="height: 100%" src="https://media.giphy.com/media/sSgvbe1m3n93G/giphy.gif" alt="Loading...">';

  // Restore the button text after 1 second (1000 milliseconds)

  }

  buttonElement.addEventListener('click', onButtonClick);



  buttonElement.appendChild(appDiv);
  buttonElement.addEventListener('click', () => {
    console.log('Asking MindMate.');
    askMindMate();
  });

  document.querySelectorAll('._acrb')[0].appendChild(buttonElement);

}

let interval = setInterval(()=>{
  if (document.querySelectorAll("._acrb").length) {
    addButton();
    clearInterval(interval);
  }
}, 200)

