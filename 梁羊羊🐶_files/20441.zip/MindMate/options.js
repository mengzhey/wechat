document.addEventListener('DOMContentLoaded', function() {
  // Load stored settings when the options page is loaded.
  let ids = [
    'responseOrSuggestion',
    'promptResponse',
    'promptSuggestion',
    'chatExamples',
    'systemPrompt'
    ]

  // Load values
  for (let id of ids) {
    chrome.storage.sync.get([id], function(items) {
    document.getElementById(id).value = items[id] || '';
  });
  }

  // Save settings when the "Save" button is clicked
  document.getElementById('saveButton').addEventListener('click', function() {
    let data = {};
    for (let i = 0; i < ids.length; i++) {
      let inputId = ids[i];
      console.log(inputId);
      const inputValue = document.getElementById(inputId).value;
      data[inputId] = inputValue;
    }

    chrome.storage.sync.set(data, function() {
      console.log('Settings saved.');
    });

  });


});
