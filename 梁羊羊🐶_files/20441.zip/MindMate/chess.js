let play = false;
if (window.location.pathname[1] === 'p') {play = true;}
let prevFEN = "";
let prevFrom = "";
let prevTo = "";


// region copy FEN
function boardToFEN(board, iHighlight) {
  let fen = '';
  let color = 'w';

  for (let row = 0; row < 8; row++) {
    let emptySquares = 0;

    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      let coord = col * 10 + 7 - row;
      if (iHighlight.includes(coord))
      {
        if (piece)
        {
          if (piece[0]==="w") color = 'b';
          if (piece[0] === 'b') color = 'w';

          if (iHighlight[0] === coord) {
            let _ = iHighlight[0];
            iHighlight[0] = iHighlight[1];
            iHighlight[1] = _;
          }

          if (!play) {
            localStorage.moveFrom = iHighlight[0];
            localStorage.moveTo = iHighlight[1];
          }
        }
      }

      if (piece) {
        if (emptySquares > 0) {
          fen += emptySquares;
          emptySquares = 0;
        }

        fen += piece[0] === 'w' ? piece[1].toUpperCase() : piece[1].toLowerCase();
      } else {
        emptySquares++;
      }
    }

    if (emptySquares > 0) {
      fen += emptySquares;
    }

    if (row < 7) {
      fen += '/';
    }
  }

  fen += ' '+ color +' KQkq - 0 1';

  if (play) {
    localStorage.setItem('fen', fen);
  }

  return fen;
}

function createBoard(coordinates, types) {
  // Initialize an 8x8 board with null values
  const board = new Array(8).fill(null).map(() => new Array(8).fill(null));

  for (let i = 0; i < coordinates.length; i++) {
    const coordinate = coordinates[i];
    const type = types[i];

    // Extract row and column from the coordinate string
    const row = 8 - parseInt(coordinate[1]);
    const col = parseInt(coordinate[0]) - 1;

    // Assign the piece type to the board at the corresponding row and column
    board[row][col] = type;
  }

  return board;
}

function copyFEN() {

  const boardElement = document.getElementsByClassName('board')[0];
  const children = [...boardElement.children];

  const coordinates = [];
  const types = [];

  let color = 'w';
  let iHighlight = [];

  children.forEach(child => {
    try {

      if (child.classList[0] === 'highlight') {
        iHighlight.push(parseInt(child.classList[1].slice(7))-11);
      }

      let coordinate = child.classList[2].slice(7);
      const isTwoDigitIntegerString = coordinate => /^\d{2}$/.test(coordinate);
      console.assert(isTwoDigitIntegerString(coordinate));
      let type = child.classList[1];
      console.assert(type[0] === 'b' || type[1] === 'w')
      console.assert(type.length === 2);

      coordinates.push(coordinate);
      types.push(type);


    }
    catch (e) {};
  });


  const board = createBoard(coordinates, types);

  let fen = boardToFEN(board, iHighlight);

  navigator.clipboard.writeText(fen);
  return fen;
}

// endregion

function loadFEN() {
  setTimeout(()=>{document.getElementsByClassName('chess-pawn-rook')[0].click();}, 50);
  document.getElementsByClassName('load-from-pgn-textarea')[0].value = localStorage.fen;
  document.getElementsByClassName('load-from-pgn-textarea')[0].dispatchEvent(new Event('input'));
  setTimeout(()=>{
    try{
      document.getElementsByClassName('ui_v5-button-small')[0].click();
      prevFEN = localStorage.fen;
    }
    catch (e) {

    }

    }, 100);
}

function movePiece() {

  let code =
    String.fromCharCode(parseInt(localStorage.moveFrom[0])+97) +
    (1 + parseInt(localStorage.moveFrom[1])).toString()+
    String.fromCharCode(parseInt(localStorage.moveTo[0])+97) +
    (1 + parseInt(localStorage.moveTo[1])).toString();

  function simulateEnterKeyPress(inputElement) {
    // Focus on the input element before simulating the Enter key press
    inputElement.focus();

    // Create and dispatch the 'keydown' event for the Enter key
    const keydownEvent = new KeyboardEvent('keydown', {
      keyCode: 13,
      bubbles: true,
      cancelable: true
    });
    inputElement.dispatchEvent(keydownEvent);

    // Create and dispatch the 'keypress' event for the Enter key
    const keypressEvent = new KeyboardEvent('keypress', {
      keyCode: 13,
      bubbles: true,
      cancelable: true
    });
    inputElement.dispatchEvent(keypressEvent);

    // Create and dispatch the 'keyup' event for the Enter key
    const keyupEvent = new KeyboardEvent('keyup', {
      keyCode: 13,
      bubbles: true,
      cancelable: true
    });
    inputElement.dispatchEvent(keyupEvent);
  }

  const inputElement = document.getElementsByClassName('ccHelper-input')[0];
  try {
    inputElement.value = code;
    prevFrom = localStorage.moveFrom;
    prevTo = localStorage.moveTo;
  }
  catch (e) {

  }
  simulateEnterKeyPress(inputElement);
}

// copyFEN
document.addEventListener('keydown', function(event) {
  if (!play && event.code === 'Space') {
    copyFEN();
  }
});

setInterval(()=>{
  if (play) {
    copyFEN();
  }
}, 1000);

// loadFEN
setInterval(()=>{
  if (!play) {
    if (localStorage.fen !== prevFEN) {
      loadFEN();
    }
  }

  if (play) {
    if (!(localStorage.moveFrom === prevFrom && localStorage.moveTo === prevTo)) {
      movePiece();
    }
  }
}, 100);


