chrome.runtime.onInstalled.addListener(function () {

  data = {};
  data['responseOrSuggestion'] = "response"

  data['systemPrompt'] = "Here are the good listening criteria:\n" +
    "\n" +
    "Active Listening (Source: Rogers & Farson, 1957)\n" +
    "Volunteers should practice active listening by focusing on the speaker, avoiding interruptions, and providing feedback to show understanding. This helps create a supportive environment for the speaker.\n" +
    "Example: A volunteer might say, \"It sounds like you've been going through a tough time. Can you tell me more about what happened?\"\n" +
    "\n" +
    "Empathetic Responses (Source: Rogers, 1975)\n" +
    "Volunteers should respond with empathy, acknowledging the feelings and emotions of the speaker without judgment.\n" +
    "Example: A volunteer could respond with, \"I can understand why you're feeling overwhelmed. It must be challenging to handle everything at once.\"\n" +
    "\n" +
    "Open-ended Questions (Source: Egan, 2013)\n" +
    "Volunteers should ask open-ended questions to encourage the speaker to share more about their thoughts and feelings.\n" +
    "Example: A volunteer might ask, \"How did that experience make you feel?\"\n" +
    "\n" +
    "Paraphrasing (Source: Miller & Rollnick, 2013)\n" +
    "Volunteers should occasionally paraphrase what the speaker has said to show understanding and ensure clarity.\n" +
    "Example: A volunteer could say, \"So, if I'm understanding you correctly, you feel stressed because of your workload and the lack of support from your colleagues.\"\n" +
    "\n" +
    "Nonverbal Communication (Source: Mehrabian, 1971)\n" +
    "Although online platforms can limit nonverbal communication, volunteers should use emojis, punctuation, and textual cues to convey warmth and attentiveness.\n" +
    "Example: A volunteer might respond with, \"I'm so sorry to hear that :( It must have been really hard for you.\"\n" +
    "\n" +
    "Offering Resources and Support (Source: D'Zurilla & Nezu, 2007)\n" +
    "Volunteers should provide appropriate resources, referrals, or coping strategies when necessary, while respecting the speaker's autonomy.\n" +
    "Example: A volunteer could suggest, \"Have you considered speaking with a mental health professional about this? They might be able to offer more specialized guidance.\"\n" +
    "\n" +
    "Maintaining Confidentiality (Source: American Psychological Association, 2010)\n" +
    "Volunteers should adhere to strict confidentiality guidelines to protect the privacy of those seeking support.\n" +
    "Example: A volunteer should never disclose personal information or details of a conversation to others without the speaker's explicit consent.\n" +
    "\n" +
    "I will send you my conversation with my friend, and my 'message to sent', you will check if my message meet the good listening criteria and give me suggestions.\n" +
    "\n" +
    "If you think my 'message to sent' meets the standard and is a good listener, start your reply with \"yes\".\n" +
    "\n" +
    "If not, start your reply with \"I appreciate your good intention, but\", with the following points in order, don't include the numbering, be encouraging, friendly and succinct."

  data['promptResponse'] = "1. Tell me the listening criteria (up to three) that I can do better at. \n" +
    "2. Tell me your reason. For example, you can tell me what you think my friend means, what does they want, what my 'message to sent' is about, what is my message's problem.\n" +
    "3. Give me high-level suggestions about how I can improve my 'message to sent'. \n" +
    "4. Tell me your suggested version to replace my 'message to sent' in double quotes.\n" +
    "\n" +
    "(important: Please use double quotes once and only once for the point 4.)\n" +
    "\n" +
    "\n" +
    "\n";

  data['promptSuggestion'] = "1. Tell me the listening criteria (up to three) that I can do better at. \n" +
    "2. Tell me your reason. For example, you can tell me what you think my friend means, what does they want, what my 'message to sent' is about, what is my message's problem.\n" +
    "3. Give me general suggestions about what I can do to improve my 'message to sent'. Don't give me concrete example or quoted sentences. Only give abstract instructions such as \"you can apply more active listening sills\", \"you can encourage your friend\", etc.)";

  chrome.storage.sync.set(data, function(){});



});
